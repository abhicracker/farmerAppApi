// asColorPicker
// Italian (it) localization

(function ($) {
    var localization = $.asColorPicker.localization["it"] = {
        cancelText: "annulla",
        applyText: "scegli"
    };
    $.extend($.asColorPicker.defaults.buttons, localization);
})(jQuery);